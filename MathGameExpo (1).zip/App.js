import React, { useState, useEffect } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, SafeAreaView, StatusBar } from "react-native";

export default function App() {
  const [level, setLevel] = useState(null);
  const [question, setQuestion] = useState(null);
  const [answer, setAnswer] = useState("");
  const [score, setScore] = useState(0);
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (level) generateQuestion(level);
  }, [level]);

  const generateQuestion = (lvl) => {
    let q = {};
    if (lvl === 1) {
      const a = Math.floor(Math.random() * 20);
      const b = Math.floor(Math.random() * 20);
      q = { text: `${a} + ${b}`, result: a + b };
    }
    if (lvl === 2) {
      const a = Math.floor(Math.random() * 12) + 1;
      const b = Math.floor(Math.random() * 12) + 1;
      q = { text: `${a} × ${b}`, result: a * b };
    }
    if (lvl === 3) {
      const x = Math.floor(Math.random() * 10) + 1;
      const a = Math.floor(Math.random() * 5) + 1;
      const b = Math.floor(Math.random() * 10);
      const result = a * x + b;
      q = { text: `${a}x + ${b} = ${result}`, result: x };
    }
    setQuestion(q);
    setAnswer("");
    setMessage("");
  };

  const checkAnswer = () => {
    if (!question) return;
    if (Number(answer) === question.result) {
      setScore(s => s + 1);
      setMessage("✔️ إجابة صحيحة!");
    } else {
      setScore(s => s - 1);
      setMessage(`❌ خطأ! الإجابة الصحيحة هي ${question.result}`);
    }
    setTimeout(() => generateQuestion(level), 600);
  };

  const Button = ({ title, onPress, outline }) => (
    <TouchableOpacity onPress={onPress} style={[styles.btn, outline && styles.btnOutline]}>
      <Text style={[styles.btnText, outline && styles.btnTextOutline]}>{title}</Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" />
      <View style={styles.container}>
        <Text style={styles.header}>لعبة تقوية الحساب</Text>
        {!level ? (
          <View style={styles.menu}>
            <Button title="مستوى 1: جمع وطرح" onPress={() => setLevel(1)} />
            <Button title="مستوى 2: ضرب وقسمة" onPress={() => setLevel(2)} />
            <Button title="مستوى 3: معادلات" onPress={() => setLevel(3)} />
          </View>
        ) : (
          <View style={styles.game}>
            <Text style={styles.label}>السؤال:</Text>
            <View style={styles.card}>
              <Text style={styles.question}>{question?.text}</Text>
            </View>

            <TextInput
              keyboardType="numeric"
              style={styles.input}
              value={answer}
              onChangeText={setAnswer}
              placeholder="اكتب الإجابة"
              placeholderTextColor="#999"
            />

            <Button title="تحقق" onPress={checkAnswer} />
            <Text style={styles.message}>{message}</Text>
            <Text style={styles.score}>النقاط: {score}</Text>

            <View style={{height:10}} />
            <Button title="الرجوع" onPress={() => { setLevel(null); setScore(0); }} outline />
          </View>
        )}

        <View style={styles.footer}>
          <Text style={styles.footerText}>مصنوع بحب ♥️ — Math Game</Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#0f1724" },
  container: { flex: 1, padding: 18, justifyContent: "center" },
  header: { fontSize: 26, color: "#fff", textAlign: "center", marginBottom: 20, fontWeight: "700" },
  menu: { gap: 12 },
  game: { alignItems: "center" },
  label: { color: "#cbd5e1", marginBottom: 8, fontSize: 16 },
  card: { backgroundColor: "#1e293b", padding: 20, borderRadius: 12, width: "100%", alignItems: "center", marginBottom: 12 },
  question: { fontSize: 36, color: "#fff", fontWeight: "700" },
  input: { borderWidth: 1, borderColor: "#334155", borderRadius: 10, width: "60%", textAlign: "center", padding: 10, color: "#fff", marginBottom: 12 },
  btn: { backgroundColor: "#06b6d4", paddingVertical: 12, borderRadius: 10, alignItems: "center", marginVertical: 6 },
  btnText: { color: "#042a2b", fontWeight: "700", fontSize: 16 },
  btnOutline: { backgroundColor: "transparent", borderWidth: 1, borderColor: "#94a3b8" },
  btnTextOutline: { color: "#94a3b8" },
  message: { marginTop: 10, color: "#fff", fontSize: 16 },
  score: { marginTop: 8, color: "#f8fafc", fontSize: 18, fontWeight: "700" },
  footer: { position: "absolute", bottom: 10, left: 0, right: 0, alignItems: "center" },
  footerText: { color: "#94a3b8" }
});
