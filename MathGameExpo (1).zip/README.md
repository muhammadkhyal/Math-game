# Math Game (Expo)

This is an Expo React Native project for the Math Game.
Run with:
1. Install Expo CLI: `npm install -g expo-cli`
2. In project folder: `npm install`
3. Start Metro: `npm start` or `expo start`
4. Scan QR with Expo Go app or run `expo run:android`

To build an APK in the cloud (no computer required) use EAS:
1. Install EAS CLI: `npm install -g eas-cli`
2. Login: `eas login`
3. Configure: `eas build:configure`
4. Build: `eas build -p android --profile preview`

